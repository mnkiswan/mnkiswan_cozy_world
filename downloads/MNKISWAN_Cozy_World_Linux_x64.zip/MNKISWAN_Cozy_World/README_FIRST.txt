MNKISWAN: COZY WORLD — GODOT 4.7.2

A playable 3D woodland life game based on the supplied GDD and character kit.

WINDOWS: Run MNKISWAN_Cozy_World.exe. No Godot editor is required.
LINUX: chmod +x MNKISWAN_Cozy_World.x86_64, then launch it.

WASD/Arrows: move | Mouse: look | E: interact/reel | Space: jump
Shift: run | I/Tab: bag | J: journal | M: map | Esc: pause/back
1-5: seed selection | Mouse wheel: camera distance | F5: save

First goal: gather at least 3 berries in Sunshine Forest, find the Village
Park community board, and deliver A welcome basket. The map can pin a place
on your compass. Recipes/quests protect required items from selling.

Includes 13 regions, 12 requests and a village-gathering ending; farming,
fishing, animals, trading, upgrades, home storage/furnishing and save/load.

This is a playable foundation with procedural 3D characters and scenery.
Final character likeness approval, authored animation/art, complete NPC
routines and commercial-release QA remain. Windows was exported but has
not been executed on this Linux host. See BUILD_NOTES.md for scope.

Saves: Godot user:// (OS-specific app_userdata/MNKISWAN · Cozy World).
Backups are automatic. No online account, telemetry or API key is needed.
